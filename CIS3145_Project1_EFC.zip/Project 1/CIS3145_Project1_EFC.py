#Name: Eyob Chekle
#Project Name: Baseball Team Manager; Project 1
#Start Date: 9/26/2022
#Description: Program that allows a manager to track data for players and make changes
#Help on validate function, option 4 &5, batting average

#Import Statements
import FileIO


#Function for Displaying the Menu
def display_menu():
    print("MENU OPTIONS")
    print("1 - Display lineup")
    print("2 - Add player")
    print("3 - Remove player")
    print("4 - Move player")
    print("5 - Edit player position")
    print("6 - Edit player stats")
    print("7 - Exit Program")
    print()

#Function for calculating batting average
def calculate_batting_avg(my_hits, my_bats):
    try:
        batting_avg = int(my_hits) / int(my_bats)
        return str(round(batting_avg,3))
    except ZeroDivisionError as e:
        print(type(e), e)
        print("A ZeroDivisionError occured")
        return None
    except ValueError as e:
        print(type(e), e)
        print("Valid Integer is required.")
    except Exception as e:
        print("This error occured in the 'calculate_batting_avg' function")

    
#Function for Displaying Lineup
def display_lineup(my_list):
    print("\tPlayer\t\tPOS\tAB\tH\tAVG")
    print("------------------------------------------------------")
    #Use a for loop to display all the players and associated stats
    count = 1
    for row in my_list:
        print(str(count) + "\t" + row[0] + "\t\t" + row[1] + "\t" + str(row[2]) + "\t" + str(row[3])+ "\t " + str(calculate_batting_avg(row[3],row[2])))
        count = count + 1
    print()
    
#Function for Adding a player  
def add_new_player(my_list):
    #Get input from users
    player_name = input("Enter Player Name: ")
    player_position = validate_position()
    player_at_bats = input("Enter At Bats: ")
    if player_at_bats == "":
        raise ValueError("Numeric Input is required")
    player_hits = input("Enter Hits: ")
    if player_hits == "":
        raise ValueError("Numeric Input is required")
##    if player_at_bats < player_hits:
##        raise ValueError("Your number of hits can't be more than at bats.")

    #Create a single list and add each elements to the list
    player = []
    player.append(player_name)
    player.append(player_position)
    player.append(player_at_bats)
    player.append(player_hits)

    #Add single list to the list of all players
    my_list.append(player)

    #This will call the function to write to the CSV File
    FileIO.writeToCSVFile(my_list)

    print(player_name + " was added")
    print()

#Function for Validating Position
def validate_position():
    valid_positions = ('C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF', 'P')
    while True:
        position = input("Enter the player's position: ")
        i=0
        tuple_index = -1
        while i < len(valid_positions):
            #print("Tuple element is:", valid_positions[i])
            
            if valid_positions[i] == position:
                tuple_index = i
                break
            i += 1
        if tuple_index != -1:
            return position
        else:
            print("That is not a valid position. Please enter a valid position")
            print("POSITIONS")
            print("C, 1B, 2B, 3B, SS, LF, CF, RF, P")
            print("+++++++++++++++++++++++++++++++++++++++++++++++++++\n")
        

#Function for Deleting a Player
def delete_from_lineup(my_list):
    deleted_player = input("Enter the player name: ")

    # Search for a matching player in the parameter list of players
    i = 0
    list_index = -1
    while i < len(my_list):
        if my_list[i][0] == deleted_player:
            list_index = i
            break
        i += 1

    #If a match is found then delete the player
    if list_index != -1:
        my_player = my_list.pop(list_index)
        print("'" + my_player[0] + "' was deleted.")
        #This will call the function to write to the CSV File
        FileIO.writeToCSVFile(my_list)
        
    #Else display a message that no match was found
    else:
        print("No player with the name of " + deleted_player + " was found.")

    print()


#Function for editing player stats
def edit_player_stats(my_list):
    edited_player = input("Enter the player's name: ")

    #Search for a matching player
    i = 0
    list_index = -1
    while i < len(my_list):
        if my_list[i][0] == edited_player:
            list_index = i
            break
        i += 1

    #If a match is found then ask for input for new value
    if list_index != -1:
        player_position = validate_position()
        player_at_bats = input("Enter at bats: ")
        player_hits = input("Enter hits: ")

        chosenEdit = my_list.pop(list_index)
        my_list.insert(list_index, [edited_player,player_position,player_at_bats,player_hits])

        print("Sucessfully Modified\n")
        #This will call the function to write to the CSV File
        FileIO.writeToCSVFile(my_list)

    else:
        print("Invalid Player, please check spelling")

#Function for editing player position
def edit_player_position(my_list):
    edited_player = input("Enter a name to edit: ")

    #Search for Player
    i = 0
    list_index = -1
    while i < len(my_list):
        if my_list[i][0] == edited_player:
            list_index = i
            break
        i += 1
    #Confirm Player with User
    if list_index != -1:
        print("You selected", my_list[i][0], "POS=", my_list[i][1])
        new_player_position = validate_position()
        player_at_bats = my_list[i][2]
        player_at_hits = my_list[i][3]

        chosenEdit = my_list.pop(list_index)
        my_list.insert(list_index, [edited_player, new_player_position, player_at_bats,player_at_hits])

        print("Sucessfully Modified\n")
        #This will call the function to write to the CSV File
        FileIO.writeToCSVFile(my_list)
        
    else:
        print("Invalid Player, please check spelling\n")

#Function for Moving a player
def move_player(my_list):
    current_lineup = int(input("Enter a current lineup number to move: "))

    current_lineup = current_lineup - 1
    place_holder = my_list.pop(current_lineup)
    print(place_holder[0], "was selected.")

    new_lineup = input("Enter a new lineup number: ")
    new_lineup = int(new_lineup) - 1
    my_list.insert(new_lineup, place_holder)

    print(place_holder[0], "was moved.\n")

    #This will call the function to write to the CSV File
    FileIO.writeToCSVFile(my_list)
        


#Main Function
def main():
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++")
    print("\tBaseball Team Management Program")

    #Lists of Lists for Part 1
##    lineupList = [['Trevor', 'SS', '588', '173'], ['Garrett', '2B', '299', '74'], 
##                   ['Tony', 'C', '535', '176'], ['Hunter', 'RF', '580', '182'],
##		    ['Ian', 'CF', '443', '113'], ['Nolan', '3B', '588', '185'], 				['Daniel', '1B', '438', '122'], ['David', 'LF', '374', '113'], 
##		    ['Phillip', 'P', '102', '12'] ] 

    #List of Lists for PART 2, READING from a CSV File
    lineupList = []
    try:
        lineupList = FileIO.read_From_CSV_File()
    except FileNotFoundError as e:
        print(type(e), e)
        print("Error occured while reading from the CSV File.")

    
    #Display Menu Function
    display_menu()

    print("POSITIONS")
    print("C, 1B, 2B, 3B, SS, LF, CF, RF, P")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++")
    
    #While loop to gather input from users with added input validation
    while True:
        command = input("Menu option: ")
        if command == '1':
            display_lineup(lineupList)
        elif command == '2':
            add_new_player(lineupList)
        elif command == '3':
            delete_from_lineup(lineupList)
        elif command == '4':
            move_player(lineupList)
        elif command == '5':
            edit_player_position(lineupList)
        elif command == '6':
            edit_player_stats(lineupList)
        elif command == '7':
            break
        else:
            print("This is not a valid option. Please try again.\n")
            display_menu()
    
    print("Bye!")






if __name__ == "__main__":
    main()









    
