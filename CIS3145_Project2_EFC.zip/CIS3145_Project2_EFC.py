#Name: Eyob Chekle
#Project Name: Baseball Team Manager; Project 1
#Start Date: 9/26/2022
#Description: Program that allows a manager to track data for players and make changes


#Import Statements
import FileIO
from datetime import date, time, datetime, timedelta


#Function for Displaying the Menu
def display_menu():
    print("MENU OPTIONS")
    print("1 - Display lineup")
    print("2 - Add player")
    print("3 - Remove player")
    print("4 - Move player")
    print("5 - Edit player position")
    print("6 - Edit player stats")
    print("7 - Exit Program")
    print()

#Function for calculating batting average
def calculate_batting_avg(my_hits, my_bats):
    try:
        batting_avg = int(my_hits) / int(my_bats)
        #return 0
        return str(round(batting_avg,3))
    except ZeroDivisionError as e:
        #print(type(e), e)
        #print("A ZeroDivisionError occured")
        batting_avg = 0
        return str(batting_avg)
    except ValueError as e:
        #print(type(e), e)
        #print("Valid Integer is required.")
        batting_avg = 0
        return str(batting_avg)
    except Exception as e:
        batting_avg = 0
        return str(batting_avg)
        #print("There was an error in calculating the batting average of the player.")

    
#Function for Displaying Lineup
def display_lineup(my_list):
    #print("\tPlayer\t\tPOS\tAB\tH\tAVG")
    print(f"{'#':3}{'Player':31}{'POS':6}{'AB':6}{'H':6}{'AVG':8}")
    print("----------------------------------------------------------")
    #Use a for loop to display all the players and associated stats
    count = 1
    for item in my_list:
        batting_avg = float(calculate_batting_avg(item['hits'],item['at_bats']))
        print(f"{str(count):3}{item['name']:31}{item['position']:6}{str(item['at_bats']):6}{str(item['hits']):6}{batting_avg:8.3f}")
        count += 1

    
#Function for Adding a player  
def add_new_player(my_list):
    #Get input from users using a While Loop
    while True:
        player_name = input("Enter Player Name: ")
        player_position = validate_position()
        player_at_bats = input("Enter At Bats: ")
        player_hits = input("Enter Hits: ")

        #If condition to validate inputs
        if int(player_at_bats) > 0 and int(player_hits) > 0 and int(player_at_bats) >= int(player_hits):
            break
        else:
            print("Values are either negative or the player hits are greater than the player's at bats.")

    #Create a single list and add each elements to the list

    #Add single list to the list of all players
    my_list.append({'name':player_name, 'position':player_position, 'at_bats':str(player_at_bats), 'hits':str(player_hits)})

    #This will call the function to write to the CSV File
    FileIO.writeToCSVFile(my_list)

    print(player_name + " was added")
    print()

#Function for Validating Position
def validate_position():
    valid_positions = ('C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF', 'P')
    while True:
        position = input("Enter the player's position: ")
        i=0
        tuple_index = -1
        while i < len(valid_positions):
            #print("Tuple element is:", valid_positions[i])
            
            if valid_positions[i] == position:
                tuple_index = i
                break
            i += 1
        if tuple_index != -1:
            return position
        else:
            print("That is not a valid position. Please enter a valid position")
            print("POSITIONS")
            print("C, 1B, 2B, 3B, SS, LF, CF, RF, P")
            print("+++++++++++++++++++++++++++++++++++++++++++++++++++\n")
        

#Function for Deleting a Player
def delete_from_lineup(my_list):
    deleted_player = input("Enter the player's name: ")

    # Search for a matching player in the parameter list of players
    i = 0
    list_index = -1
    while i < len(my_list):
        if my_list[i]['name'] == deleted_player:
            list_index = i
            break
        i += 1

    #If a match is found then delete the player
    if list_index != -1:
        my_player = my_list.pop(list_index)
        print("'" + my_player['name'] + "' was deleted.")
        #This will call the function to write to the CSV File
        FileIO.writeToCSVFile(my_list)
        
    #Else display a message that no match was found
    else:
        print("No player with the name of " + deleted_player + " was found.")

    print()


#Function for editing player stats
def edit_player_stats(my_list):
    edited_player = input("Enter the player's name: ")

    #Search for a matching player
    i = 0
    list_index = -1
    while i < len(my_list):
        if my_list[i]['name'] == edited_player:
            list_index = i
            break
        i += 1

    #If a match is found then ask for input for new value
    if list_index != -1:
        while True:
            player_position = validate_position()
            player_at_bats = input("Enter at bats: ")
            player_hits = input("Enter hits: ")
            #If condition to validate inputs
            if int(player_at_bats) > 0 and int(player_hits) > 0 and int(player_at_bats) >= int(player_hits):
                break
            else:
                print("Values are either negative or the player hits are greater than the player's at bats.")

        #Update values in the list of dictionaries
        my_list[list_index]['position'] = player_position
        my_list[list_index]['at_bats'] = player_at_bats
        my_list[list_index]['hits'] = player_hits

        print("Successfully Modified\n")
        #This will call the function to write to the CSV File
        FileIO.writeToCSVFile(my_list)

    else:
        print("Invalid Player, please check spelling")

#Function for editing player position
def edit_player_position(my_list):
    edited_player = input("Enter a name to edit: ")

    #Search for Player
    i = 0
    list_index = -1
    while i < len(my_list):
        if my_list[i]['name'] == edited_player:
            list_index = i
            break
        i += 1
    #Confirm Player with User
    if list_index != -1:
        print("You selected", my_list[i]['name'], "POS=", my_list[i]['position'])
        new_player_position = validate_position()

        #Update the lists of dictionary using index value
        my_list[list_index]['position'] = new_player_position


        print("Successfully Modified\n")
        #This will call the function to write to the CSV File
        FileIO.writeToCSVFile(my_list)
        
    else:
        print("Invalid Player, please check spelling\n")

#Function for Moving a player
def move_player(my_list):
    current_lineup = int(input("Enter a current lineup number to move: "))

    current_lineup = current_lineup - 1
    place_holder = my_list.pop(current_lineup)
    print(place_holder['name'], "was selected.")

    new_lineup = input("Enter a new lineup number: ")
    new_lineup = int(new_lineup) - 1
    my_list.insert(new_lineup, place_holder)

    print(place_holder['name'], "was moved.\n")

    #This will ca20ll the function to write to the CSV File
    FileIO.writeToCSVFile(my_list)
        
#Function for Date
def current_and_game_date():
    try:
        today_date = date.today()
        print("CURRENT DATE:\t", today_date)
        game_date = input("GAME DATE:\t ")
        if game_date == '':
            print()
            return None
        else:
            #Split the current date and assign it values
            current_date = str(date.today()).split("-")
            current_date = date(int(current_date[0]),int(current_date[1]),int(current_date[2]))
            #Split the game date while converting the values to Int & assign it values
            game_date = game_date.split("-")
            game_date = date(int(game_date[0]),int(game_date[1]),int(game_date[2]))
            #Do the calculation
            print("DAYS UNTIL GAME:",(game_date - current_date).days)
            print()
    except Exception as e:
        print("There was an error in calculating the days remaining until the game.")


#Main Function
def main():
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++")
    print("\tBaseball Team Management Program")

##    lineupList = [
##        {"name":"Dominick Gilbert", "position":"1B", "at_bats":537, "hits":170},
##        {"name":"Craig Mitchell", "position":"CF", "at_bats":396, "hits":125},
##        {"name":"Jack Quinn", "position":"RF", "at_bats":345, "hits":99},
##        {"name":"Simon Harris", "position":"C", "at_bats":450, "hits":135},
##        {"name":"Darryl Moss", "position":"3B", "at_bats":501, "hits":120},
##        {"name":"Grady Guzman", "position":"SS", "at_bats":463, "hits":114},
##        {"name":"Wallace Cruz", "position":"LF", "at_bats":443, "hits":131},
##        {"name":"Cedric Cooper", "position":"2B", "at_bats":165, "hits":54},
##        {"name":"Alberto Gomez", "position":"P", "at_bats":72, "hits":19}]

    #List of Lists for PART 2, READING from a CSV File
    lineupList = []
    try:
        lineupList = FileIO.read_From_CSV_File()
    except FileNotFoundError as e:
        print(type(e), e)
        print("Error occured while reading from the CSV File.")

    
    #Current Date and Game Date Function
    current_and_game_date()

    
    #Display Menu Function
    display_menu()

    print("POSITIONS")
    print("C, 1B, 2B, 3B, SS, LF, CF, RF, P")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++")
    
    #While loop to gather input from users with added input validation
    while True:
        command = input("Menu option: ")
        if command == '1':
            display_lineup(lineupList)
        elif command == '2':
            add_new_player(lineupList)
        elif command == '3':
            delete_from_lineup(lineupList)
        elif command == '4':
            move_player(lineupList)
        elif command == '5':
            edit_player_position(lineupList)
        elif command == '6':
            edit_player_stats(lineupList)
        elif command == '7':
            break
        else:
            print("This is not a valid option. Please try again.\n")
            display_menu()
    
    print("Bye!")






if __name__ == "__main__":
    main()









    
