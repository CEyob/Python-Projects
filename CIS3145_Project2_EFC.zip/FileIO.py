import csv

#Define constants
CSV_FILENAME = "players.csv"

###Write to CSV File
##def writeToCSVFile(my_list):
##    try:
##        with open(CSV_FILENAME, "w", newline="") as file:
##            writer_object = csv.writer(file)
##            writer_object.writerows(my_list)
##    except Exception as e:
##        print(type(e), e)
##        print("This error occured while writing to the CSV file.")
##
###Read from a CSV File
##def read_From_CSV_File():
##    try:
##        players = []
##        with open(CSV_FILENAME, "r", newline="") as file:
##            reader_object = csv.reader(file)
##            for row in reader_object:
##                players.append(row)
##
##        return players
##
##    except FileNotFoundError as e:
##        print("A file")

def writeToCSVFile(my_list):
    with open(CSV_FILENAME, "w", newline="") as file:
            writer_object = csv.writer(file)
            for row in my_list:
                writer_object.writerow(row.values())



def read_From_CSV_File():
    players = []
    with open(CSV_FILENAME, "r", newline="") as file:
        reader_object = csv.reader(file)
        for row in reader_object:
            dictionary = {"name": row[0],
                          "position": row[1],
                          "at_bats": row[2],
                          'hits': row[3]}
            players.append(dictionary)
    return players
        
