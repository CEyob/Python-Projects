#Name: Eyob Chekle
#Project Name: Baseball Team Manager; Project 3
#Start Date: 11/14/2022
#Description: Program that allows a manager to track data for players and make changes


#Import Statements
import db as FileIO
import objects
from datetime import date, time, datetime, timedelta


#Function for Displaying the Menu
def display_menu():
    print("MENU OPTIONS")
    print("1 - Display lineup")
    print("2 - Add player")
    print("3 - Remove player")
    print("4 - Move player")
    print("5 - Edit player position")
    print("6 - Edit player stats")
    print("7 - Exit Program")
    print()

    
#Function for Displaying Lineup
def display_lineup(my_list):
    #print("\tPlayer\t\tPOS\tAB\tH\tAVG")
    print(f"{'#':3}{'Player':31}{'POS':6}{'AB':6}{'H':6}{'AVG':8}")
    print("----------------------------------------------------------")
    #Use a for loop to display all the players and associated stats
    for i, aPlayer in enumerate(my_list, start = 1):
        print(f"{str(i):3}{aPlayer.get_full_name():31}{aPlayer.get_position():>6}{str(aPlayer.get_at_bats()):>6}{str(aPlayer.get_hits()):>6}{aPlayer.calculate_batting_avg():>8.3f}")
        
    
#Function for Adding a player  
def add_new_player(my_list):
    #Get input from users using a While Loop
    while True:
        player_firstName = input("\nEnter Player's First Name: ")
        player_lastName = input("Enter Player's Last Name: ")
        player_position = validate_position()
        player_at_bats = input("Enter At Bats: ")
        player_hits = input("Enter Hits: ")

        #If condition to validate inputs
        if int(player_at_bats) >= 0 and int(player_hits) >= 0 and int(player_at_bats) >= int(player_hits):
            break
        else:
            print("Values are either negative or the player hits are greater than the player's at bats.")

    #Create a single object and add each object to the list
    myPlayer = objects.Player(player_firstName, player_lastName, player_position, player_at_bats, player_hits)
    my_list.add_player(myPlayer)

    #This will call the function to write to the CSV File
    FileIO.write_to_txt_file(my_list)

    print(player_firstName, "was added\n")
    print()

#Function for Validating Position
def validate_position():
    valid_positions = ('C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF', 'P')
    while True:
        position = input("Enter the player's position: ")
        i=0
        tuple_index = -1
        while i < len(valid_positions):
            #print("Tuple element is:", valid_positions[i])
            
            if valid_positions[i] == position:
                tuple_index = i
                break
            i += 1
        if tuple_index != -1:
            return position
        else:
            print("That is not a valid position. Please enter a valid position")
            print("POSITIONS")
            print("C, 1B, 2B, 3B, SS, LF, CF, RF, P")
            print("+"*60)
            print()
        

#Function for Deleting a Player
def delete_from_lineup(my_list):
    deleted_player = int(input("\nEnter the lineup number to remove: "))

    #Input Validation
    if deleted_player < 1 or deleted_player > my_list.get_player_count():
        print("Invalid lineup number.")
        print("Enter a value between 1 and " + str(my_list.get_player_count()))
    else:
        #Remove the player from the list
        player = my_list.remove_player(deleted_player-1)
        print("Lineup #", deleted_player, "was removed\n")

        #Call the function to write to the txt file
        FileIO.write_to_txt_file(my_list)
        


#Function for editing player stats
def edit_player_stats(my_list):
    deleted_player = int(input("\nEnter the lineup number to edit: "))

    #Input Validation
    if deleted_player < 1 or deleted_player > my_list.get_player_count():
        print("Invalid lineup number.")
        print("Enter a value between 1 and " + str(my_list.get_player_count()))
    else:
        #Remove the player from the list
        player = my_list.remove_player(deleted_player-1)
        #print()
        while True:
            player_firstName = input("Enter Player's First Name: ")
            player_lastName = input("Enter Player's Last Name: ")
            player_position = validate_position()
            player_at_bats = input("Enter At Bats: ")
            player_hits = input("Enter Hits: ")

            #If condition to validate inputs
            if int(player_at_bats) >= 0 and int(player_hits) >= 0 and int(player_at_bats) >= int(player_hits):
                break
            else:
                print("Values are either negative or the player hits are greater than the player's at bats.")

        #Create a single object and add each object to the list
        myPlayer = objects.Player(player_firstName, player_lastName, player_position, player_at_bats, player_hits)
        my_list.add_player(myPlayer)
        lastValue = my_list.get_player_count()
        my_list.move_player(lastValue, deleted_player)

        print("Successfully Modified\n")
        FileIO.write_to_txt_file(my_list)
        
    

#Function for editing player position
def edit_player_position(my_list):
    first_name = input("\nEnter the player's first name to edit: ")
    #first_name += " "
    #There is an issue with the file download where there is an extra space in-between names
    #I don't know if this is intended but I removed the space in between the names
    last_name = input("Enter the player's last name to edit: ")
    edited_player = first_name + " " + last_name
    #print(edited_player)

    #For loop to reiterate through list of objects and change position
    for aPlayer in my_list:
        player_object = str(aPlayer)
        if player_object == edited_player:
            print(aPlayer, "with POS:", aPlayer.get_position(), "was selected")
            new_position = validate_position()
            aPlayer.set_position(new_position)
            print("Successfully Modified\n")
            FileIO.write_to_txt_file(my_list)
            
    

#Function for Moving a player
def move_player(my_list):
    #Choose a current lineup number
    current_lineup = int(input("\nEnter a current lineup number to move: "))
    print(my_list.get_player(current_lineup - 1), "was selected")

    #Ask for new lineup number
    new_lineup = int(input("Enter a new lineup number: "))
    my_list.move_player(current_lineup, new_lineup)

    print(my_list.get_player(new_lineup - 1), "was moved\n")

    #This will call the function to write to the CSV File
    FileIO.write_to_txt_file(my_list)
        
#Function for Date
def current_and_game_date():
    try:
        today_date = date.today()
        print("CURRENT DATE:\t", today_date)
        game_date = input("GAME DATE:\t ")
        if game_date == '':
            print()
            return None
        else:
            #Split the current date and assign it values
            current_date = date.today()
            #Split the game date while converting the values to Int & assign it values
            game_date = game_date.split("-")
            game_date = date(int(game_date[0]),int(game_date[1]),int(game_date[2]))
            #Do the calculation
            print("DAYS UNTIL GAME:",(game_date - current_date).days)
            print()
    except Exception as e:
        print("There was an error in calculating the days remaining until the game.")


#Main Function
def main():
    print("+"*60)
    print("\tBaseball Team Management Program")

    #lineupList = []
    try:
        lineupList = FileIO.read_from_txt_file()
    except FileNotFoundError as e:
        print(type(e), e)
        print("Error occured while reading from the CSV File.")

    
    #Current Date and Game Date Function
    current_and_game_date()

    
    #Display Menu Function
    display_menu()

    print("POSITIONS")
    print("C, 1B, 2B, 3B, SS, LF, CF, RF, P")
    print("+"*60)
    
    #While loop to gather input from users with added input validation
    while True:
        command = input("Menu option: ")
        if command == '1':
            display_lineup(lineupList)
        elif command == '2':
            add_new_player(lineupList)
        elif command == '3':
            delete_from_lineup(lineupList)
        elif command == '4':
            move_player(lineupList)
        elif command == '5':
            edit_player_position(lineupList)
        elif command == '6':
            edit_player_stats(lineupList)
        elif command == '7':
            break
        else:
            print("This is not a valid option. Please try again.\n")
            display_menu()
    
    print("Bye!")






if __name__ == "__main__":
    main()









    
