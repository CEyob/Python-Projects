import csv
import objects
import pickle

#Define constants
FILE_NAME = "players.txt"

###Write to CSV File
##def writeToCSVFile(my_list):
##    try:
##        with open(CSV_FILENAME, "w", newline="") as file:
##            writer_object = csv.writer(file)
##            writer_object.writerows(my_list)
##    except Exception as e:
##        print(type(e), e)
##        print("This error occured while writing to the CSV file.")
##
###Read from a CSV File
##def read_From_CSV_File():
##    try:
##        players = []
##        with open(CSV_FILENAME, "r", newline="") as file:
##            reader_object = csv.reader(file)
##            for row in reader_object:
##                players.append(row)
##
##        return players
##
##    except FileNotFoundError as e:
##        print("A file")

##def writeToCSVFile(my_list):
##    with open(CSV_FILENAME, "w", newline="") as file:
##            writer_object = csv.writer(file)
##            for row in my_list:
##                writer_object.writerow(row.values())
##
##
##
##def read_From_CSV_File():
##    players = []
##    with open(CSV_FILENAME, "r", newline="") as file:
##        reader_object = csv.reader(file)
##        for row in reader_object:
##            dictionary = {"name": row[0],
##                          "position": row[1],
##                          "at_bats": row[2],
##                          'hits': row[3]}
##            players.append(dictionary)
##    return players


#Function for reading from File using Lineup Object
def read_from_txt_file():
    try:
        # Create a Object to hold all players in the file
        playerList = objects.Lineup()
        
        
        # Open the file and read each row of the file
        with open(FILE_NAME, newline="") as file:
            reader = csv.reader(file)
            i = 1
            for row in reader:
                # Create a Player object and add it to the Lineup Object
                player = objects.Player(row[0], row[1], row[2], row[3], row[4])
                playerList.add_player(player)

        # Return the Lineup object
        return playerList
        
    except FileNotFoundError:
        return None

#Function for writing to a file using Lineup Object
def write_to_txt_file(my_list):
    with open(FILE_NAME, "w", newline="") as file:
        for i, aPlayer in enumerate(my_list, start = 1):
            file.write(aPlayer.get_first_name() + ",")
            file.write(aPlayer.get_last_name() + ",")
            file.write(aPlayer.get_position() + ",")
            file.write(aPlayer.get_at_bats() + ",")
            file.write(aPlayer.get_hits() + "\n")
            
        





      
