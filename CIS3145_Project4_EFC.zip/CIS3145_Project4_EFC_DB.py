#Name: Eyob Chekle
#Project Name: Baseball Team Manager; Project 4
#Start Date: 12/11/2022
#Description: Program that allows a manager to track data for players and make changes

#Imports
import sqlite3
from contextlib import closing

from objects import Player, Lineup

#Database connections
conn = None


def connect():
    global conn
    if not conn:
        DB_FILE = "player_db.sqlite"
        conn = sqlite3.connect(DB_FILE)
        conn.row_factory = sqlite3.Row


def close():
    if conn:
        conn.close()

#Make_player
def make_player(row):
    return Player(row["playerID"],row["batOrder"], row["firstName"], row["lastName"], row["position"], row["atBats"], row["hits"])




def get_players():
    #return None #remove this line when code is added.
    # SQL statement to select all 7 fields for all players
    query = '''SELECT playerID, batOrder, firstName, lastName, position, atBats, hits
                FROM Player'''
    # Use a with statement to execute the query
    with closing(conn.cursor()) as c:
        c.execute(query)
        results = c.fetchall()

    # Create a lineup object
    players = Lineup()
    # use a loop to populate the lineup object with player objects
    for row in results:
        #players.add_player(make_player(row))
        player = Player(row["playerID"],row["batOrder"], row["firstName"], row["lastName"], row["position"], row["atBats"], row["hits"])
        players.add_player(player)
        
    # return the lineup object
    return players



def get_player(playerID):
    #return None #remove this line when code is added.
    # SQL statement to select all 7 fields for a player
    query = '''SELECT playerID, batOrder, firstName, lastName, position, atBats, hits
                FROM Player WHERE playerID = ?'''

    #  Use a with statement to execute the query & return a player object if the player exists
    with closing(conn.cursor()) as c:
        c.execute(query, (playerID,))
        row = c.fetchone()
        if row:
            return make_player(row)
        else:
            return None

def add_player(player):
    #return None #remove this line when code is added.
    # SQL statement to insert 6 fields for a player added to the table
    sql = '''INSERT INTO Player (batOrder, firstName, lastName, position, atBats, hits)
                VALUES (?, ?, ?, ?, ?, ?)'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (player.bat_order, player.first_name, player.last_name, player.position, player.at_bats, player.hits))
        conn.commit()

    # Use a with statement to execute the query


def delete_player(player):
    #return None #remove this line when code is added.
    # SQL statement to delete a single player
    sql = '''DELETE FROM Player WHERE playerID = ?'''
    
    # Use a with statement to execute the query
    with closing(conn.cursor()) as c:
        c.execute(sql, (player,))

        conn.commit()



def update_bat_order(lineup):
    #return None #remove this line when code is added.
    # Use a loop to call a SQL statement that updates
    # the batOrder for each player based on their playerID
    #players = Lineup()
    for player in lineup:
        sql = '''UPDATE Player
                    SET batOrder = ?
                WHERE playerID = ?'''
        with closing(conn.cursor()) as c:
            c.execute(sql, (player.bat_order, player.player_id))

            conn.commit()
        

def update_player(bat_order,first_name,last_name,position,at_bats,hits, player_id):
    #return None #remove this line when code is added.
    # SQL statement to update 6 fields of a player based on the playerID
    sql = '''UPDATE Player
                SET batOrder = ?,
                    firstName = ?,
                    lastName = ?,
                    position = ?,
                    atBats = ?,
                    hits = ?
            WHERE playerID = ?'''
    # Use a with statement to execute the query
    with closing(conn.cursor()) as c:
        c.execute(sql, (bat_order,first_name,last_name,position,at_bats,hits,player_id))

        conn.commit()


##def main():
##    # code to test the get_players function
##    connect()
####    eyob = Player(bat_order = 1, first_name = "Test", last_name = "Player Edited", position = "C", at_bats = 4, hits = 5)
####    update_player(eyob)
####    add_player(eyob)
##
##    
##
##    #delete_player(11)
##
##    get_player(2)
##    print("This is the get player function: ", get_player(2))
##
##    
##    
##    players = get_players()
##    if players != None:
##        for player in players:
##            print(player.player_id,player.bat_order, player.first_name, player.last_name,
##                  player.position, player.at_bats, player.hits, player.calculate_batting_avg())
##            #print(player.get_at_bats)
##            #print(player.first_name)
##    else:
##        print("Code is needed for the get_players function.")
##
##if __name__ == "__main__":
##    main()
