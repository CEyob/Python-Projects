#Name: Eyob Chekle
#Project Name: Baseball Team Manager; Project 4
#Start Date: 12/11/2022
#Description: Program that allows a manager to track data for players and make changes


#Import Statements
#import db as FileIO
import objects
from datetime import date, time, datetime, timedelta
import CIS3145_Project4_EFC_DB as FileIO


#Function for Displaying the Menu
def display_menu():
    print("MENU OPTIONS")
    print("1 - Display lineup")
    print("2 - Add player")
    print("3 - Remove player")
    print("4 - Move player")
    print("5 - Edit player position")
    print("6 - Edit player stats")
    print("7 - Exit Program")
    print()

    
#Function for Displaying Lineup
def display_lineup(my_list):
    #my_list = FileIO.get_players()
    if my_list == None:
        print("The lineup is empty")
        return

    
    #print("\tPlayer\t\tPOS\tAB\tH\tAVG")
    print(f"{'#':3}{'Player':31}{'POS':>6}{'AB':>6}{'H':>6}{'AVG':>8}")
    print("-"*60)
    if my_list != None:
        for player in my_list:
            print(f"{str(player.bat_order):3}{player.get_full_name():31}{player.get_position():>6}{str(player.get_at_bats()):>6}{str(player.get_hits()):>6}{player.calculate_batting_avg():>8.3f}")

    
        
    
#Function for Adding a player  
def add_new_player(my_list):
    #my_list = FileIO.get_players()
    if my_list == None:
        print("The lineup is empty")
        return
    
    #Get input from users using a While Loop
    while True:
        player_firstName = input("\nEnter Player's First Name: ")
        player_lastName = input("Enter Player's Last Name: ")
        player_position = validate_position()
        player_at_bats = input("Enter At Bats: ")
        player_hits = input("Enter Hits: ")
        player_batOrder = my_list.get_player_count() + 1

        #If condition to validate inputs
        if int(player_at_bats) >= 0 and int(player_hits) >= 0 and int(player_at_bats) >= int(player_hits):
            break
        else:
            print("Values are either negative or the player hits are greater than the player's at bats.")

    #Create a single object and add each object to the list
    myPlayer = objects.Player(bat_order = player_batOrder, first_name = player_firstName, last_name = player_lastName, position = player_position, at_bats = player_at_bats, hits = player_hits)

    #Database Function from db
    #FileIO.connect()
    FileIO.add_player(myPlayer)

    print(player_firstName, "was added\n")
    print()

#Function for Validating Position
def validate_position():
    valid_positions = ('C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF', 'P')
    while True:
        position = input("Enter the player's position: ")
        i=0
        tuple_index = -1
        while i < len(valid_positions):
            #print("Tuple element is:", valid_positions[i])
            
            if valid_positions[i] == position:
                tuple_index = i
                break
            i += 1
        if tuple_index != -1:
            return position
        else:
            print("That is not a valid position. Please enter a valid position")
            print("POSITIONS")
            print("C, 1B, 2B, 3B, SS, LF, CF, RF, P")
            print("+"*60)
            print()
        

#Function for Deleting a Player
def delete_from_lineup(my_list):
    #Database retreival
    #my_list = FileIO.get_players()
    if my_list == None:
        print("The lineup is empty")
        return
    
    deleted_player = int(input("\nEnter the lineup number to remove: "))

    #Input Validation
    if deleted_player < 1 or deleted_player > my_list.get_player_count():
        print("Invalid lineup number.")
        print("Enter a value between 1 and " + str(my_list.get_player_count()))
    else:
        #Remove the player from the list
        player = my_list.remove_player(deleted_player-1)
        print("Lineup #", deleted_player, "was removed\n")

        #Call the function to write to the txt file
        FileIO.delete_player(deleted_player)
        


#Function for editing player stats
def edit_player_stats(my_list):
    #my_list = FileIO.get_players()
    if my_list == None:
        print("The lineup is empty")
        return
    
    deleted_player = int(input("\nEnter the lineup number to edit: "))

    #Input Validation
    if deleted_player < 1 or deleted_player > my_list.get_player_count():
        print("Invalid lineup number.")
        print("Enter a value between 1 and " + str(my_list.get_player_count()))
    else:
        #Remove the player from the list
        player = my_list.remove_player(deleted_player-1)
        #print()
        while True:
            player_firstName = input("Enter Player's First Name: ")
            player_lastName = input("Enter Player's Last Name: ")
            player_position = validate_position()
            player_at_bats = input("Enter At Bats: ")
            player_hits = input("Enter Hits: ")
            player_batOrder = deleted_player

            #If condition to validate inputs
            if int(player_at_bats) >= 0 and int(player_hits) >= 0 and int(player_at_bats) >= int(player_hits):
                break
            else:
                print("Values are either negative or the player hits are greater than the player's at bats.")

        #Create a single object and add each object to the list
        myPlayer = objects.Player(player_firstName, player_lastName, player_position, player_at_bats, player_hits)
        my_list.add_player(myPlayer)
        lastValue = my_list.get_player_count()
        my_list.move_player(lastValue, deleted_player)

        print("Successfully Modified\n")
        #FileIO.write_to_txt_file(my_list)
        #Database Changes
        FileIO.update_player(player_batOrder,player_firstName,player_lastName,player_position,player_at_bats,player_hits,deleted_player)
        
    

#Function for editing player position
        
def edit_player_position(my_list):
    #my_list = FileIO.get_players()
    if my_list == None:
        print("The lineup is empty")
        return
    
    first_name = input("\nEnter the player's first name to edit: ")
    #first_name += " "
    #There is an issue with the file download where there is an extra space in-between names
    #I don't know if this is intended but I removed the space in between the names
    last_name = input("Enter the player's last name to edit: ")
    edited_player = first_name + " " + last_name
    #print(edited_player)

    #For loop to reiterate through list of objects and change position
    for aPlayer in my_list:
        player_object = str(aPlayer)
        if player_object == edited_player:
            player_object = aPlayer
            print(aPlayer, "with POS:", aPlayer.get_position(), "was selected")
            new_position = validate_position()
            aPlayer.set_position(new_position)
            print("Successfully Modified\n")
            FileIO.update_player(player_object.bat_order,player_object.first_name,player_object.last_name,player_object.position,player_object.at_bats,player_object.hits,player_object.player_id)
            
    

#Function for Moving a player
def move_player(my_list):
    #my_list = FileIO.get_players()
    if my_list == None:
        print("The lineup is empty")
        return
    
    #Choose a current lineup number
    current_lineup = int(input("\nEnter a current lineup number to move: "))
    print(my_list.get_player(current_lineup - 1), "was selected")

    #Ask for new lineup number
    new_lineup = int(input("Enter a new lineup number: "))
    my_list.move_player(current_lineup, new_lineup)

    print(my_list.get_player(new_lineup - 1), "was moved\n")

    #This will call the function to write to the CSV File
    FileIO.update_bat_order(my_list)

        
#Function for Date
def current_and_game_date():
    #For Project 3 feedback, you(professor) marked me down .5 points for not using current_date = date.today()
    #However, when I looked at the zip file I turned in, I did exactly what you said to do in the feedback
    try:
        # Get the current date
        today_date = date.today()
        print("CURRENT DATE:\t", today_date)

        # Ask the user for the game date
        game_date_str = input("GAME DATE:\t ")

        # If the user didn't enter a game date return
        if game_date_str == '':
            return None
        else:

            # Split the game date string into its year, month, and day 
            year, month, day = map(int, game_date_str.split("-"))

            # Create a date object from the year, month, and day
            game_date = date(year, month, day)

            # Calculate the difference between the current date and the game date
            days_until_game = (game_date - today_date).days

            # Print the result
            print("DAYS UNTIL GAME:", days_until_game)
            print()
    except Exception as e:
        print("There was an error in calculating the days remaining until the game.")


#Main Function
def main():
    print("+"*60)
    print("\tBaseball Team Management Program")

    #Database connection from db
    #I didn't use the get_players() function here because I didn't want to load it only
    #Once when the program starts but rather each time a function access the lineup list
    try:
        FileIO.connect()
    except Exception as e:
        print(type(e), e)
        print("There was an error while attempting to make the database connection.")
        
    lineupList = []

    
    #Current Date and Game Date Function
    current_and_game_date()

    
    #Display Menu Function
    display_menu()

    print("POSITIONS")
    print("C, 1B, 2B, 3B, SS, LF, CF, RF, P")
    print("+"*60)
    
    #While loop to gather input from users with added input validation
    while True:
        command = input("Menu option: ")
        if command == '1':
            lineupList = FileIO.get_players()
            display_lineup(lineupList)
        elif command == '2':
            lineupList = FileIO.get_players()
            add_new_player(lineupList)
        elif command == '3':
            lineupList = FileIO.get_players()
            delete_from_lineup(lineupList)
        elif command == '4':
            lineupList = FileIO.get_players()
            move_player(lineupList)
        elif command == '5':
            lineupList = FileIO.get_players()
            edit_player_position(lineupList)
        elif command == '6':
            lineupList = FileIO.get_players()
            edit_player_stats(lineupList)
        elif command == '7':
            break
        else:
            print("This is not a valid option. Please try again.\n")
            display_menu()
    
    print("Bye!")






if __name__ == "__main__":
    main()









    
