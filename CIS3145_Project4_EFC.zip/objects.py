#Name: Eyob Chekle
#Project Name: Baseball Team Manager; Project 4
#Start Date: 12/11/2022
#Description: Module containting the code for the object's Player, and Lineup

#Import Statements


#Player Class
class Player:
    #Constructor
    def __init__(self, player_id = 0, bat_order = 0, first_name = "", last_name = "", position = "", at_bats = 0, hits = 0):
        self.first_name = first_name
        self.last_name = last_name
        self.position = position
        self.at_bats = at_bats
        self.hits = hits
        self.player_id = player_id
        self.bat_order = bat_order


    #Method to return full name
    def get_full_name(self):
        return self.first_name + " " + self.last_name
    #Method to return position
    def get_position(self):
        return self.position
    #Method to return at_bats
    def get_at_bats(self):
        return self.at_bats
    #Method to return hits
    def get_hits(self):
        return self.hits
    #Method to get first name
    def get_first_name(self):
        return self.first_name
    #Method
    def get_last_name(self):
        return self.last_name

    #Method for setting position for edit_stats
    #Instructions said nothing about extra methods in the Player class
    #Therefore, I'm assuming we're allowed to use more methods besides the 2
    def set_position(self, position):
        self.position = position

    #Method to return batting average
    def calculate_batting_avg(self):
        batting_avg = 0
        try:
            batting_avg = int(self.hits) / int(self.at_bats)
        except ZeroDivisionError as e:
            batting_avg = 0
        except ValueError as e:
            batting_avg = 0
        except Exception as e:
            batting_avg = 0
        return batting_avg

    #Str method just in case its required
    def __str__(self):
        return self.get_full_name()

    




#Lineup Class
class Lineup:
    def __init__(self):
        #Private List Attribute
        self.__lineup_list = []

    def add_player(self, player_object):
        self.__lineup_list.append(player_object)

    def remove_player(self, lineup_number = 0):
        return self.__lineup_list.pop(lineup_number)

    def get_player(self, lineup_number = 0):
        return self.__lineup_list[lineup_number]

    def get_player_count(self):
        return len(self.__lineup_list)

    def move_player(self, old_lineup_num = 0, new_lineup_num = 0):
        old_lineup_num = old_lineup_num - 1
        place_holder = self.__lineup_list.pop(old_lineup_num)
        
        new_lineup_num = new_lineup_num - 1
        self.__lineup_list.insert(new_lineup_num, place_holder)

    #Iteration
    # create an __iter__ and __next__ method.
    def __iter__(self):
        self.__index = -1
        return self

    def __next__(self):
        if self.__index == len(self.__lineup_list)-1:
            raise StopIteration
        self.__index += 1
        player = self.__lineup_list[self.__index]
        return player

    
        
        
        
    








    

