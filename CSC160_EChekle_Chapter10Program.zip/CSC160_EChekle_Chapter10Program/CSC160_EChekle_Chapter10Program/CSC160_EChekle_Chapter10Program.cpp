// CSC160_EChekle_Chapter10Program.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

using namespace std;
int main()
{
    std::cout << "Hello World!\n";




}


