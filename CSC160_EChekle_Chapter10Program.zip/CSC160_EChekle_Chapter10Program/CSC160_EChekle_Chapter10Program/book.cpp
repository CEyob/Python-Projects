#include <iostream>
#include <iomanip>
#include "book.h"

void book::setTitle(a)
{

}

void book::showAuthor()const
