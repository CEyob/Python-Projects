//Code for my class
#include <string>

using namespace std;
//Create it
class book
{
public:
	//Getters
	void showTitle()const;
	void showAuthor()const;
	void showPublisher()const;
	void showIsbn()const;
	void showPrice()const;
	void showNumberOfCopies()const;

	//Setters
	void setTitle(string a);
	void setAuthor(string a, string b, string c, string d);
	void setPublisher(string a);
	void setIsbn(int a);
	void setPrice(double a);
	void setNumberOfCopies(int a);

	//Other Functions
	bool checkIfSame(book)const;

private:
	string title;
	string author;
	string publisher;
	int Isbn;
	double price;
	int numberOfCopies;

};
