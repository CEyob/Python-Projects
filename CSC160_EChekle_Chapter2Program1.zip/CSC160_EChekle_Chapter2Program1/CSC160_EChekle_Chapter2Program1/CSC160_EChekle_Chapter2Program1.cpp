// Chapter 2 Program by Eyob Chekle

#include <iostream>
using namespace std;

int main()
{
    //Declare my variables
    int num1, num2, num3, average;

    //Assign values to my variables
    num1 = 115;
    num2 = 29;
    num3 = -15;

    //Equation for Average
    average = (num1 + num2 + num3) / 3;

    //Write my output statements
    cout << "Number 1: " << num1 << endl;
    cout << "Number 2: " << num2 << endl;
    cout << "Number 3: " << num3 << endl;

    cout << "Average: " << average << endl;

    
    //return statement
    return 0;
}

