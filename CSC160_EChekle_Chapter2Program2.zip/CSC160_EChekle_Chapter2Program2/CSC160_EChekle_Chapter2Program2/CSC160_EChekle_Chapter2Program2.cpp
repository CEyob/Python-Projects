//Chapter 2 Program 2 by Eyob Chekle, 6/11/2020
//

#include <iostream>
using namespace std;

int main()
{
	//Declare Variables
	int capacity, miles; //miles = number of miles it can be driven without refueling
	double mpg; //mpg = miles per gallon
	
	//Input statements
	cout << "Enter the capacity of the fuel tank(integers): ";
	cin >> capacity;
	cout << endl;

	cout << "Enter the miles per gallon the car can be driven(decimal): ";
	cin >> mpg;
	cout << endl;

	//Calculations
	miles = mpg * capacity;

	//Ouput statement
	cout << "Possible miles driven without refueling: " << miles << endl;

	//End
	return 0;


}


