// CSC160_EChekle_Chapter4Program.cpp : This file contains the 'main' function. Program execution begins and ends there.
//Chapter 4 Program by Eyob Chekle, 06/25/2020


// Header files
#include <iostream>

using namespace std;

int main()
{
    //Declare variables
	int boxesOfCookies, containersOfCookies, cookies;

	//Input for number of cookies
	cout << "Enter the number of cookies you have currently: ";
	cin >> cookies;

	//Calculations for boxes of cookies
	boxesOfCookies = cookies / 24;			//24 is how much cookies a box can hold
	
	//Output results for the number of boxes of cookies
	if ((cookies % 24) > 0)
	{
		cout << "The number of cookie boxes needed to hold the cookies: " << boxesOfCookies << endl;
		cout << "Leftover cookies: " << cookies % 24 << endl;
	}
	else
	{
		cout << "The number of cookie boxes needed to hold the cookies: " <<
			boxesOfCookies << endl;
	}

	//Calculations for containers of cookies
	containersOfCookies = boxesOfCookies / 75; //75 is how much boxes a contaner can hold

	//Ouput results for the number of containers of cookies
	if ((boxesOfCookies % 75) > 0)
	{
		cout << "The number of containers needed are: " << containersOfCookies << endl;
		cout << "Leftover boxes: " << boxesOfCookies % 75 << endl;
	}
	else
	{
		cout << "The number of containers needed are: " <<
			containersOfCookies << endl;
	}



	return 0;




}


