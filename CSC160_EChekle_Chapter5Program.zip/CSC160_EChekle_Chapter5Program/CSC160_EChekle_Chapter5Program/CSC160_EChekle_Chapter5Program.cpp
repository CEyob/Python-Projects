// CSC160_EChekle_Chapter5Program.cpp : This file contains the 'main' function. Program execution begins and ends there.
//By Eyob Chekle, 7/2/2020

//Header Files
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    //Declare Variables
    int firstNum, secondNum;
    int counter;
    int sumOfEven;
    int sumSquareOddNum;

    char chCounter;

    sumOfEven = 0;
    sumSquareOddNum = 0;


    //Collect Information from input
    cout << "Enter two numbers." << endl;
    cout << "First Number must be less than the second number you enter!" << endl;
    cout << "Enter numbers: ";
    cin >> firstNum >> secondNum;

    cout << "Your first number is: " << firstNum << " and your second number is: "
        << secondNum << endl;

    cout << " " << endl;

    //Output all odd numbers between firstNum and secondNum
    //Check to see if the first number is even to begin
    if (firstNum % 2 == 0)
    {
        counter = firstNum + 1;
    }
    else
    {
        counter = firstNum;
    }

    // Run a while loop to output all odd numbers
    //Loop will only begin if counter <= secondNum
    while (counter <= secondNum)
    {
        cout << counter << " ";
        counter = counter + 2;
    }
    cout << endl;

    //Run a if loop to set the counter on an even number
    if (firstNum % 2 == 0)
        counter = firstNum;
    else
        counter = firstNum + 1;

    //Run a while loop to output the sum of all even numbers
    while (counter <= secondNum)
    {
        sumOfEven = sumOfEven + counter;
        counter = counter + 2;
    }

    //Ouput statement from sumOfEven
    cout << "The sum of even integers between " << firstNum << " and "
        << secondNum << " is: " << sumOfEven << endl;
       
    cout << " " << endl;
    
    //Output statement for Number, and square of number
    cout << "Number     Square of Number" << endl;
    counter = 1;

    while (counter <= 10)
    {
        cout << setw(4) << counter << setw(18)
            << counter * counter << endl;
        counter++;
    }
    cout << endl;

    //Determine square of odd numbers
    //Check to see number to begin with is odd first
    if (firstNum % 2 == 0)
        counter = firstNum + 1;
    else
        counter = firstNum;

    //While statement to compute the squared sum of all odd numbers
    while (counter <= secondNum)
    {
        sumSquareOddNum = sumSquareOddNum + counter * counter;
        counter = counter + 2;
    }

    //Ouput statement
    cout << "Sum of the squares of odd integers between your first number and second number: "
        << sumSquareOddNum << endl;

    //Output all uppercase letters
    cout << "Upper case letters are: ";

    chCounter = 'A';

    //While loop to increment by 1 and print char
    while (chCounter <= 'Z')
    {
        cout << chCounter << " ";
        chCounter++;
    }
    cout << endl;



    return 0;
} 


