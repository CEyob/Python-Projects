// CSC160_EChekle_Chapter6Program.cpp : This file contains the 'main' function. Program execution begins and ends there.
//By Eyob Chekle, 07/9/2020, Chapter 6 Program

//Header Files
#include <iostream>
#include <cmath>
using namespace std;

//Function Prototypes
void userInput(int& v, int& t);
int windChill(int v, int t);

int main()
{
	//Declare Variables
	int windSpeed, temp;
	int windChillEquation;

	//Assign Values
	windSpeed = 0;
	temp = 0;

	//Run a function to collect wind speed and temperature from user
	userInput(windSpeed, temp);

	//Run a function to run the windchill equation
	windChillEquation = windChill(windSpeed, temp);

	//Output Results
	cout << "Current Temperature: " << temp << "F" << endl;
	cout << "Windchill Factor: " << windChillEquation << "F" << endl;
}

//Function to collect wind speed and temp
void userInput(int& v, int& t)
{
	cout << "Enter wind speed in miles per hour: ";
	cin >> v;

	cout << "Enter temperature in degree Fahrenheit: ";
	cin >> t;

}

//Function to run the windchill equation
int windChill(int v, int t)
{
	int w;

	//Equation
	w = 35.74 + 0.6215 * t - 35.75 * pow(v, 0.16) + 0.4275 * t * pow(v, 0.16);

	//Return value
	return w;
}