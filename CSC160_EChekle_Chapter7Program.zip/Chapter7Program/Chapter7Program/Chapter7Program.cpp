// Chapter7Program.cpp : This file contains the 'main' function. Program execution begins and ends there.
//Chapter 7 program by Eyob CHekle

#include <iostream>
#include <string>

using namespace std;

int main()
{
   //Declare my variables
    string censored, censored2;
    string str;

    //Assign the empty xxx values
    censored = "xxx-xx-xxxx ";
    censored2 = " xxxxxxxx";

    //Collect user input
    cout << "Please enter your first name, last name, social security number, user id, and password seperated by spaces: " << endl;
    getline(cin, str);

    //REplace the ssn with a censored version
    //11 is where you start, 12 is how far you go. Its the range
    str.replace(11, 12, censored);

    //Replace the password with censored version
    str.erase(29, 33);
    str.insert(29, censored2);

    //Print statement
    cout << str << endl;

    return 0;


}


