// CSC160_EChekle_Chapter8Program.cpp : This file contains the 'main' function. Program execution begins and ends there.
//By Eyob Chekle, 7/23/2020, Chapter 8 Program

//Header Files
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

int main()
{
    //Declare my variables
    string canidateName[5];
    int candidateVotes[5];
    double percentOfVotes[50];

    int i;
    int sum;
    int largestScale;

    //Collect input
    cout << "Enter candidate name and votes recieved by that candidate: " << endl;

    for (i = 0; i < 5; i++)//Loop to do input for each candidate
    {
        cin >> canidateName[i] >> candidateVotes[i];

    }

    //Calculate the sum of the votes
    sum = 0;

    for (i = 0; i < 5; i++)
    {
        sum = sum + candidateVotes[i];
    }

    //Calculate the percentage of the votes
    for (int x = 0; x < 5; x++)
    {
        percentOfVotes[x] = candidateVotes[x] * 100.0 / sum;
    }

    //Calculate the biggest votes
    int maxIndex = 0;
    
    for (int index = 0; index < 5; index++)
    {
        if (candidateVotes[maxIndex] > candidateVotes[index])
            maxIndex = index;

        largestScale = candidateVotes[maxIndex];
    }

    //Output the results
    cout << "  " << endl;
    cout << "Candidate" << "    " << "Votes Recieved" << "    " << "% of Total Votes" << endl;
    
    for (i = 0; i < 5; i++)
    {
        cout << fixed << showpoint << setprecision(2);
        cout << setw(10) << setw(10) << left << canidateName[i] << "       " << setw(10) << candidateVotes[i] << "      "
            << percentOfVotes[i] << endl;
    }

    cout << "Total amount of votes: " << sum << endl;
    cout << "The winner of the race is: " << canidateName[largestScale];
    
    return 0;
}


