// CSC160_EChekle_Chapter9Program.cpp : This file contains the 'main' function. Program execution begins and ends there.
//Chpater 9 Program by Eyob Chekle


//Headerfiles
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>



//Namespace
using namespace std;

//Define structs
struct studentType
{
    string studentFName;
    string studentLName;
    int testScore;
    char grade;
};

//Array of 20 components of type studentType
studentType student[20];

//Function prototypes
void readIn(studentType& student);

int highestScore(studentType, int a);

void printResults(studentType, int a);

int main()
{
    //Open files
    ifstream infile;
    ofstream outfile;
    infile.open("Ch9_Ex2Data.txt");
    outfile.open("Ch9_Ex2Out.txt");

    //Declare Variables


    //Call for function readIN
    readIn(student[19]);
    
    //Call for function print results
    //The function to find highest score is inside this function. 
    //The function for assigning grades has been combined with readIn function
    printResults(student[19], 20);
    
    //Cout
    cout << "Please check the text files: ";

    //Close files
    infile.close();
    outfile.close();

    //Return
    return 0;



}

//Function for reading in data
void readIn(studentType&)
{
    //Open files
    ifstream infile;
    ofstream outfile;
    infile.open("Ch9_Ex2Data.txt");
    outfile.open("Ch9_Ex2Out.txt");

    int counter;

    for (counter = 0; counter < 20; counter++)
    {
        infile >> student[counter].studentFName;
        infile >> student[counter].studentLName;
        infile >> student[counter].testScore;

        if (student[counter].testScore >= 90)
            student[counter].grade = 'A';
        else if (student[counter].testScore >= 80)
            student[counter].grade = 'B';
        else if (student[counter].testScore >= 70)
            student[counter].grade = 'C';
        else if (student[counter].testScore >= 60)
            student[counter].grade = 'D';
        else
            student[counter].grade = 'F';
    }

    //Close files
    infile.close();
    outfile.close();
}


//Function for finding highest scores
int highestScore(studentType, int a)
{
    int highest = 0;

    for (int i = 0; i < a; i++)
    {
        if (highest < student[i].testScore)
            highest = student[i].testScore;

    }

    return highest;
}

//Function for printing highest scores
void printResults(studentType, int a)
{
    ofstream outfile;
    outfile.open("Ch9_Ex2Out.txt");

    //Declare Variables
    string name;
    int i, highest;


    //Format results
    outfile << left << setw(30) << "Student Name" << right << setw(10) << "TestScore" << right << setw(7) << "Grade" << endl;

    //Loop for printing names
    for (i = 0; i < a; i++)
    {
        name = student[i].studentLName + " " + student[i].studentFName;

        outfile << left << setw(30) << name << right << setw(10) << student[i].testScore << right << setw(7) << student[i].grade << endl;

    }

    outfile << endl;

    highest = highestScore(student[19], 20);

    outfile << "Highest Test Score: " << highest;

    outfile << "Students with the highest test scores: " << endl;

    //Loop for names, I was able to understand how to do all the "highest" stuff thru a youtube video 
    //https://www.youtube.com/watch?v=noeadrmcVMI

    for (i = 0; i < 20; i++)
    {
        if (student[i].testScore == highest)
            outfile << student[i].studentLName << " " << " " << student[i].studentFName << endl;

    }
    
    //Close files
    outfile.close();
}