// CSC160_Echekle_Chapter3Program.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

//This will allow me to use the setfill functions
#include <iomanip>

//This is used for the file I/O
#include <fstream>

using namespace std;

int main()
{
    //Declare my variables
    double boxTicketPrices, sidelineTicketPrices, premiumTicketPrices, generalTicketPrices;
    int boxTicketsSold, sidelineTicketsSold, premiumTicketsSold, generalTicketsSold;
    int totalBoxTickets, totalSidelineTickets, totalPremiumTickets, totalGeneralTickets;
    double totalSaleAmount;
    int numberOfTickets;

    //Declare file stream variables
    ifstream inData;
    ofstream outData;

    //Open the files
    inData.open("Ch3_Ex5Data.txt");
    outData.open("Ch3_Ex5Out.txt");

    //Assign values from the files to the variables
    inData >> boxTicketPrices >> boxTicketsSold >> sidelineTicketPrices >> sidelineTicketsSold
        >> premiumTicketPrices >> premiumTicketsSold >> generalTicketPrices >> generalTicketsSold;

    //Do my calculations for total sale amount
    totalBoxTickets = boxTicketPrices * boxTicketsSold;
    totalSidelineTickets = sidelineTicketPrices * sidelineTicketsSold;
    totalPremiumTickets = premiumTicketPrices * premiumTicketsSold;
    totalGeneralTickets = generalTicketPrices * generalTicketsSold;

    totalSaleAmount = totalBoxTickets + totalSidelineTickets + totalPremiumTickets + totalGeneralTickets;
    
    //Do my calculations for the total number of tickets sold
    numberOfTickets = boxTicketsSold + sidelineTicketsSold + premiumTicketsSold + generalTicketsSold;

   
    //Output to the ouput file my results
    outData << fixed << showpoint << setprecision(2);
    outData << "Number of tickets sold = " << numberOfTickets << endl;
    outData << "Sale amount = " << totalSaleAmount << endl;

    //Close files
    inData.close();
    outData.close();

    //Print Statements
    cout << "Processing Data" << endl;
    cout << "Data has been processed. Check Appropriate Folder in File Explorer to see the in data and the out data in their respective text files" << endl;
    cout << "Solution Explorer, Right click on project, Open Folder in File Explorer. If you are struggling in finding the files" << endl;



    return 0;


}


