#Name: Eyob Chekle
#Assignment: CH07 Monthly Sales Output
#9/22/2022
#This program will display monthly sales data, and calculate total and average sale amounts
#This program will now have a way to save this data

#Imports
import csv

#Defined Constants for use in Functions
CSV_FILENAME = "monthly_sales.csv"

#Function for displaying menu
def displayMenu():
    print("Command Menu")
    print("monthly - View monthly sales")
    print("yearly - View yearly summary")
    print("edit - Edit sales for a month")
    print("exit - Exit program")

#Function for viewing monthly sales
def viewMonthly(myList):
    print("Month - Sales")
    #Attempt at a for loop to itterate through the loop and display months
    for row in myList:
        print(row[0] + " - " + str(row[1]))

    print()

#Function for viewing total and average sale amounts
def viewYearly(myList):
    total = 0
    for item in myList:
        total = total + int(item[1])
    print("Yearly total: ", total, "\nMonthly Average: ", round(total/len(myList),2))


#Function attempt at editing list   
def editSales(myList):
    month = input("Three-letter Month: ")

    #Search for matching month
    i = 0
    listIndex = -1
    while i < len(myList):
        if myList[i][0] == month:
            listIndex = i
            break
        i += 1

    #If match is found then ask for input for new value
    if listIndex != -1:
        salesEdit = str(input("Sales Amount: "))
        
        chosenEdit = myList.pop(listIndex)
        myList.insert(listIndex, [month, salesEdit])
        
        print("Sales amount for ", month, " was modified")
        
        #This will call the function to write to the CSV File
        writeToCSVFile(myList)
        print("The file ",CSV_FILENAME, "has been updated")
    else:
        print("Invalid Three Letter Month!") 

    print()
            
#Function for reading from a CSV File
def readFromCSVFile():
    monthsWithSales = []
    with open(CSV_FILENAME, "r", newline = "") as file:
        reader_object = csv.reader(file)
        for row in reader_object:
            monthsWithSales.append(row)

        return monthsWithSales

#Function for writing to a CSV File
def writeToCSVFile(myList):
    with open(CSV_FILENAME, "w", newline = "") as file:
        writer_object = csv.writer(file)
        writer_object.writerows(myList)



def main():
    print("Monthly Sales Program")
    print()


    #Read from the CSV File Function
    monthlySales = []
    monthlySales = readFromCSVFile()
    
    displayMenu()

    #While loop to keep repeating the menu choices for user
    while True:
        command = input("\nEnter Option Choice: ")

        #Calls the function to view all the monthly sales
        if command == 'monthly':
            viewMonthly(monthlySales)
        #Calls the function for yearly totals
        elif command == 'yearly':
            viewYearly(monthlySales)
        #Calls the function to edit sales for a month
        elif command == 'edit':
            editSales(monthlySales)
        elif command == 'exit':
            break
        else:
            print("This is not a valid option. Please try again.\n")
            displayMenu()

    print("Bye!")
            
            


        









if __name__ == "__main__":
    main()
    

    

    
