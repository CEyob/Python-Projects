#Name: Eyob Chekle
#Date: 10/06/22
#Assignment: Chapter 09 Sales Report
#Description: Create a program that dynamically displays a report of sales by quarter

#Import Statements
import locale


#Function for converting number to currency
def convertCurrency(x):
    locale.setlocale(locale.LC_ALL, "us")
    properCurrency = locale.currency(x, grouping = True)
    return properCurrency



#Function for Displaying the sales report
def displaySalesReport(myList):
    regionValue = 1
    print(f"{'Region':25}{'Q1':14}{'Q2':14}{'Q3':14}{'Q4':14}")
    for item in myList:
        #print(regionValue, item[0], item[1], item[2], item[3])
        print(f"{regionValue:0}{item[0]:26}{item[1]:14}{item[2]:14}{item[3]:14}")
        regionValue += 1
    



#Function for displaying total sales by region
def totalRegionSales(myList):
    total = 0
    regionValue = 1
    print("\nTotal Sales by region: ")
    for item in myList:
        total = total + item[0]+item[1]+item[2]+item[3]
        print("Region " + str(regionValue) + ": " + str(convertCurrency(total)))
        total = 0
        regionValue += 1
        




#Function for displaying total sales by quarter
def totalQuarterSales(myList):
    count = 0
    sumSales = 0
    print("\nTotal Sales by Quarter")

    for item in range(len(myList)):
        count += 1
        sumSales = 0
        for x in myList:
            sumSales += x[item]
        print("Q" + str(count) + ": " + str(convertCurrency(sumSales)))
    




#Function for total anual sales for all regions
def totalAnualSales(myList):
    total = 0
    for item in myList:
        total = total + item[0]+item[1]+item[2]+item[3]
        #print(total)
    print("\nTotal annual sales, all regions: ", convertCurrency(total))
  




#Main Function
def main():
    print("Sales Report")

    #List of Lists containing sales
    sales = [[1540.0, 2010.0, 2450.0, 1845.0],#Region 1
            [1130.0, 1168.0, 1847.0, 1491.0],#Region 2
            [1580.0, 2305.0, 2710.0, 1284.0],#Region 3
            [1105.0, 4102.0, 2391.0, 1576.0]]#Region 4

    #Call the function to display the sales report
    displaySalesReport(sales)

    #Calls the function to display total sales by region
    totalRegionSales(sales)

    #Calls the function to display quarter sales
    totalQuarterSales(sales)

    #Calls total annual sales
    totalAnualSales(sales)
    












if __name__== "__main__":
    main()

