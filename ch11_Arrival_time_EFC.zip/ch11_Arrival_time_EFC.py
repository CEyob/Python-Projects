#Name: Eyob Chekle
#Date: 10/13/2022
#Assignment: CH11 Arrival Time Calculator
#Description: This program will take a set of inputs and output the Create a program that calculates the estimated duration of a trip in hours and minutes.

#Import Statements
from datetime import date, time, datetime, timedelta

#Function for outputting estimated travel time
def displayInfo(HH, MM, AD, AT):
    print("\nEstimated Travel Time: ")
    print("Hours: ",HH)
    print("Minutes: ", MM)
    print("Estimated date of arrival: ", AD)
    print("Estimated time of arrival: ", AT)
    
    



#Function for outputing estimated travel time







#Main Function
def main():
    while True:
        #Title
        print("Arrival Time Estimator\n\n")

        #Collect Required Information
        dateOfDeparture = input("Enter date of departure (YYYY-MM-DD): ")
        timeOfDeparture = input("Enter time of departure (HH:MM AM/PM): ")

        #Datetime Object
        departure = dateOfDeparture + " " + timeOfDeparture
        departureDatetime = datetime.strptime(departure, "%Y-%m-%d %I:%M %p")
        #print(departureDatetime)
        
        #Obtain miles and mph
        miles = int(input("Enter miles: "))
        mph = int(input("Enter miles per hour: "))

        #Calculate hours/minutes
        hours = int(miles/mph)
        minutes = int(((miles/mph)-hours)*60)
        #print(hours, minutes)

        #Time Delta
        travelTime = timedelta(hours = hours, minutes = minutes)
        arrivalOfFlight = departureDatetime + travelTime
        #print(arrivalOfFlight)

        #strftime formatting
        arrivalDate = arrivalOfFlight.strftime("%Y-%m-%d")
        #print(arrivalDate)
        arrivalTime = arrivalOfFlight.strftime("%I:%M %p")
        #print(arrivalTime)

        #Calling Function to display
        displayInfo(hours, minutes, arrivalDate, arrivalTime)

        #Loop for asking again
        command = input("\n\nContinue? (y/n): ")
        if command == 'y':
            continue
        elif command == 'n':
            print("\nBye!")
            break

        
        





















#The best line of code :)
if __name__ == "__main__":
    main()

