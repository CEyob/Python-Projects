#Name: Eyob Chekle
#Assignment: CH12 Monthly Sales Output
#10/20/22
#This program will display monthly sales data, calculate totals, and allow edits
#This program will use Dictionaries instead of Lists

#Comment: Everything was working untill
#Write to File Function

#Files
import csv
FILENAME = "monthly_sales.txt"

#Function for displaying the menu
def displayMenu():
    print("Command Menu")
    print("view   - View sales for a specified month")
    print("edit   - Edit sales for a specified month")
    print("totals - View sales summary for year")
    print("exit   - Exit program")


#Function for writing to a file
def writeToTextFile(monthlySales):
    with open(FILENAME, "w", newline = "") as file:
        for monthElement in monthlySales.values():
            file.write(monthElement["month"] + "\t")
            file.write(str(monthElement["sales"]) + "\n")
    print("The", FILENAME, "file was updated.")

#Function for reading from a file
def readFromTextfile():
    monthsDictionary = {}
    try:
        with open(FILENAME, newline = "") as file:
            reader = csv.reader(file, delimiter = "\t")#I totally forgot about the delimiter argument
            #reader = csv.reader(file)
            i = 1
            #Loop through the reader object and create a dictionary
            for row in reader:
                month = {"month": row[0],
                         "sales": row[1]}
                monthsDictionary [i] = month
                i += 1
        return monthsDictionary

    except FileNotFoundError:
        return None
            

        



#Function for viewing sales for a specified month
def viewSpecificMonth(myDictionary):
    month = input("Three Letter Month: ")
    matchFound = False
    #Loop through all the items in the dictionary
    for key, item in myDictionary.items():
        if month == item["month"]:
            print("Sales amount for", item["month"], "is", str(item["sales"]))
            matchFound = True
            break
    if not matchFound:
        print("Please input the correct three letter month.")
            
                  

#Function for editing sales for a month
def editSpecificMonth(myDictionary):
##    matchFound = False
##    month = input("Three Letter Month: ")
##    #Loop Through all items in the dictionary
##    for key, item in myDictionary.items():
##        if month == item["month"]:
##            #Remove
##            my_month = myDictionary.pop(key)
##            newSales = float(input("Sales Amount: "))
##            #Add
##            month_dictionary = {"month": month,
##                                "sales": newSales}
##            length = len(myDictionary)
##            myDictionary[length + 1] = month_dictionary

            
    month = input("Three Letter Month: ")

    newSales = int(input("Sales Amount: "))
    myDictionary[month] = newSales

    #Update file
    #writeToTextFile(myDictionary)
    return myDictionary
    #print(myDictionary)



def displayTotals(myDictionary):
    total = 0
    for key, item in myDictionary.items():
        total = total + int(item["sales"])
    print("Yearly Total: {:,}".format(total))
    print("Monthly Average: {:,}" .format(float(total/len(myDictionary))))
    





def main():
    print("Monthly Sales Program")
    print()

    #Read from the text file
    monthlySales = {}
    monthlySales = readFromTextfile()

    #print(monthlySales) #test
    displayMenu()

    #While loop for menu choices
    while True:
        command = input("\nEnter Option Choice: ")

        #Calls the function to view all the monthly sales
        if command == 'view':
            viewSpecificMonth(monthlySales)
        #Calls the function for yearly totals
        elif command == 'edit':
            editSpecificMonth(monthlySales)
        #Calls the function to edit sales for a month
        elif command == 'totals':
            displayTotals(monthlySales)
        elif command == 'exit':
            break
        else:
            print("This is not a valid option. Please try again.\n")
            displayMenu()

    print("Bye!")















if __name__ == "__main__":
    main()
    
