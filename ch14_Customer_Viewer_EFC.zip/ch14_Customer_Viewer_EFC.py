#Name: Eyob Chekle
#Assignment: CH14 Weekly Exercise, Customer Viewer
#Date: 10/27/2022
#Description:allows the user to display the data for a customer by specifying the customer’s ID

#Import Statements
import csv
from customer_class import Customer

#Constants
FILENAME = "customers.csv"

#Function for reading csv file
def readFromCSVFile():
    customerList = []
    with open('customers.csv', 'r', newline = "") as file:
        reader = csv.reader(file)
        #next(reader)
        for row in reader:
            customerList.append(Customer(row[0],row[2],row[3],row[4],row[5],row[6],row[7]))
        #Remove Header row
        customerList.pop(0)
        return customerList
            



#Main Function
def main():
    print("Customer Viewer")
    print("Enter the customer ID to view the customer address")
    print()

    #Function for reading from csv file
    customerList = []
    customerList = readFromCSVFile()
    #print(customerList)
    

    #While loop to ask for customer ID
    while True:
        foundCustomer = 0
        customerLookupValue = input("\nEnter customer ID: ")
        for item in customerList:
            if item.getCus_id() == customerLookupValue:
                print()
                print(item.getFullAddress())
                print()
                foundCustomer = 1
                break
        if foundCustomer == 0:
            print("\nNo customer with that id\n")
            choice = input("\nContinue?(Y/N): ")
        elif foundCustomer == 1:
            choice = input("\nContinue?(Y/N): ")

        if choice == 'N' or choice == 'n':
            print("Bye!")
            break
            















if __name__ == "__main__":
    main()
