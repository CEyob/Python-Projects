#Name: Eyob Chekle
#Assignment: CH14 Weekly Exercise, Customer Viewer
#Date: 10/27/2022
#Description: This is the class module for the class Customer

class Customer:
    def __init__(self, cus_id = "", firstName = "", lastName = "", company = "",
                 address = "", city = "", state = "", zipcode = ""):
        self.__cus_id = cus_id
        self.__firstName = firstName
        self.__lastName = lastName
        self.__company = company
        self.__address = address
        self.__city = city
        self.__state = state
        self.__zipcode = zipcode
        
    #Get Customer ID
    def getCus_id (self):
        return self.__cus_id
    
    #Set Customer ID
    def setCus_id(self, cus_id):
        self.__cus_id = cus_id

    #Get First Name      
    def getFirstName (self):
        return self.__firstName

    #Set First Name
    def setFirstName(self, firstName):
        self.__firstName = firstName

    #Get Last Name   
    def getLastName(self):
        return self.__lastName

    #Set Last Name
    def setLastName (self, lastName):
        self.__lastName = lastName

    #Get Company
    def getCompany (self):
        return self.__company
    
    #Set Company
    def setCompany(self, company):
        self.__company = company

    #Get Address  
    def getAddress (self):
        return self.__address
    
    #Set Address
    def setAddress(self, address):
        self.__address = address

    #Get City
    def getCity(self):
        return self.__city
    
    #Set City
    def setCity (self, city):
        self.__city = city
        
    #Get State
    def getState (self):
        return self.__state
    
    #Set State
    def setState(self, state):
        self.__state = state

    #Get Zipcode
    def getZipcode(self):
        return self.__zipcode
    
    #Set Zipcode
    def setZipcode (self, zipcode):
        self.__zipcode = zipcode

    #Return full adress
    def getFullAddress(self):
        conditional = self.__company
        fullAddress = ""
        if conditional == "":
            fullAddress += self.__firstName + " " + self.__lastName + "\n"+ self.__address + "\n" + self.__city + ", " + self.__state + " " + self.__zipcode
            print(fullAddress)
##            print(self.__firstName + " " + self.__lastName + "\n" +
##                  self.__address + "\n" +
##                  self.__city + ", " + self.__state + " " + self.__zipcode)
        else:
            print(self.__firstName + " " + self.__lastName + "\n" +
                  self.__company + "\n" + self.__address + "\n" +
                  self.__city + ", " + self.__state + " " + self.__zipcode)
        #return fullAddress
        

    

        
