#Name: Eyob Chekle
#Date: 11/3/22
#Assignment: CH15 Weekly Exercise
#Description: This is the module containing the Data Entry code

#Import Statements
from company_objects import Person, Customer, Employee


#Main Function
def main():
    print("Customer/Employee Data Entry\n")

    #While loop:
    while True:
        userInput = input("Customer or employee? (c/e): ")

        #Use the input to decide what object to create
        if userInput.lower() == "c":
            print("DATA ENTRY")
            myFirstName = input("First Name: ")
            myLastName = input("Last Name: ")
            myEmail = input("Email: ")
            myCustNum = input("Number: ")

            myObject = Customer(firstName = myFirstName, lastName = myLastName, email = myEmail, custNum = myCustNum)

        if userInput.lower() == "e":
            print("DATA ENTRY")
            myFirstName = input("First Name: ")
            myLastName = input("Last Name: ")
            myEmail = input("Email: ")
            mySSN = input("SSN: ")

            myObject = Employee(firstName = myFirstName, lastName = myLastName, email = myEmail, ssn = mySSN)

        #After the object has been created print the Person's information
        if isinstance(myObject, Customer):
            print("\nCUSTOMER")
            print("Full Name: ", str(myObject))
            print("Email: ", myObject.getEmail())
            print("Number: ", myObject.getCustNum())
            print()

        if isinstance(myObject, Employee):
            print("\nCUSTOMER")
            print("Full Name: ", str(myObject))
            print("Email: ", myObject.getEmail())
            print("SSN: ", myObject.getEmployeeSSN())
            print()

        #Get further input to ask if continue
        continueProgram = input("Continue? (y/n): ")
        #continueProgram = continueProgram.islower()

        if continueProgram.lower() == "n":
            print("Bye!")
            break

            
            

            

















































#Lol
if __name__ == "__main__":
    main()

    
