#Name: Eyob Chekle
#Date: 11/3/22
#Assignment: CH15 Weekly Exercise
#Description: This is the module containing the class objects

#Person class that provides attributes for first name, l.Name, email

class Person:
    def __init__(self, firstName = "", lastName = "", email = ""):
        self.__firstName = firstName
        self.__lastName = lastName
        self.__email = email

    #Get methods for Person attributes
    def getFirstName(self):
        return self.__firstName

    def getLastName(self):
        return self.__lastName

    def getEmail(self):
        return self.__email

    #String method for printing full name
    def __str__(self):
        return self.getFirstName() + " " + self.getLastName()
    

#Customer class that uses inheritance
class Customer(Person):
    def __init__(self, firstName = "", lastName = "", email = "", custNum = 0):
        Person.__init__(self, firstName, lastName, email)
        self.__custNum = custNum

    #Get method for customer attributes
    def getCustNum(self):
        return self.__custNum

#Employee class that uses inheritance
class Employee(Person):
    def __init__(self, firstName = "", lastName = "", email = "", ssn = ""):
        Person.__init__(self, firstName, lastName, email)
        self.__ssn = ssn

    #Get method for Employee attributes
    def getEmployeeSSN(self):
        return self.__ssn



    
    
