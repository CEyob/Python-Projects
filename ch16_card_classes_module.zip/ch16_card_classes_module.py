#Name: Eyob Chekle
#Date: 11/10/22
#Assignment: Chapter 16 Card Objects
#Description: This module will contain the Card, Deck, and Hand class

#Import statements
import random

#This is the Card class with 3 public attributes
class Card:
    def __init__(self, suit= "", rank= "", value= ""):
        self.suit = suit
        self.rank = rank
        self.value = value

    def __str__(self):
        return self.rank + " of " + self.suit

#This is the Deck class which will hold 52 cards
class Deck(Card):
    def __init__(self):
        self.__deckList = []
        ranks = ["Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"]
        suits = ["Clubs", "Diamonds", "Hearts", "Spades"]

        #Loop in a loop to create a card object
        for suit in suits:
            for rank in ranks:
                position = 0
                #If statements to decide the rank
                if rank == "Ace":
                    position = 1
                elif rank == "Jack":
                    position = 11
                elif rank == "Queen":
                    position = 12
                elif rank == "King":
                    position = 13
                #For the ranks with numbers
                else:
                    position = int(rank)

                #Inheritance and append the decklist
                card = Card(suit, rank, position)
                self.__deckList.append(card)

    #Function for shuffling the decklist from constructor
    def shuffle(self):
        random.shuffle(self.__deckList)

    #Function for dealing one card
    def dealCard(self):
        randomPosition = random.randint(0, len(self.__deckList)-1)
        return self.__deckList.pop(randomPosition)

    #Function for number of cards in deck
    def count(self):
        return len(self.__deckList)

    #Iteration Function
    def __iter__(self):
        self.__index = -1
        return self

    #Next Method
    def __next__(self):
        if self.__index == len(self.__deckList)-1:
            raise StopIteration
        self.__index += 1
        card = self.__deckList[self.__index]
        return card

#This class will have methods for dealing with the hand of cards
class Hand(Card):
    def __init__(self):
        self.__privateCards = []

    #Function for adding a card to hand
    def addCard(self, card):
        self.__privateCards.append(card)

    #Function for playing card from hand
    def playCard(self, index = 0):
        return self.__privateCards.pop(index)

    #Function for counting cards in hand
    def count(self):
        return len(self.__privateCards)

    #Function for points in hand
    def totalPoints(self):
        pass

    #Iteration Function
    def __iter__(self):
        self.__index = -1
        return self

    def __next__(self):
        if self.__index == len(self.__privateCards)-1:
            raise StopIteration
        self.__index += 1
        card = self.__privateCards[self.__index]
        return card
    
    
    
                

        
        
    
