#Name: Eyob Chekle
#Date: 11/10/22
#Assignment: Chapter 16 Card Objects

#Import Modules
from ch16_card_classes_module import Card, Deck, Hand



#Main Function
def main():
    print()
    print("Cards - Tester")
    print()
    print("DECK")

    #Create the deck object
    deck = Deck()

    deckIteration = iter(deck)

    #Print the deck
    while True:
        #Try catch exceptions because iteration raises an exception: StopIteration
        try:
            card = next(deckIteration)
            print(str(card))
        except StopIteration:
            break

    #Shuffle the deck
    deck.shuffle()

    #Print the size of the deck
    print("\nShuffled Deck Count: " + str(deck.count()))
    print()

    #Deal a hand with five cards
    print("HAND\n")
    hand = Hand()

    for x in range(1, 6):
        dealtCard = deck.dealCard()
        hand.addCard(dealtCard)

    handIteration = iter(hand)

    #Print the hand
    while True:
        try:
            card = next(handIteration)
            print(str(card))
        except StopIteration:
            break

    #Print all points in hand
    print("\nHand points: " + str(hand.count()*deck.count()))

    #Print Hand Count
    print("\nHand count: " + str(hand.count()))

    #Print count of deck
    print("\nDeck count: " + str(deck.count()))

    























if __name__ == "__main__":
    main()


