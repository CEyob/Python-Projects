#Name: Eyob Chekle
#Assignment: Chapter 17 Task List
#Date: 11/18/22
#Description: Class module

#Class
class Task:
    def __init__(self, description = None, completed = None, id = 0):
        self.description = description
        self.completed = completed
        self.id = id

    
        
