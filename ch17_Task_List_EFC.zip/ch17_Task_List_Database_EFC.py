#Name: Eyob Chekle
#Assignment: Chapter 17 Task List Application
#Date: 11/18/22
#Description: Database Module

#Import statements
import sqlite3
import os
import sys
from contextlib import closing

import ch17_Task_List_Business_EFC as Task
conn = None

#Database Connection
def connect():
    global conn
    if not conn:
        conn = sqlite3.connect('task_list_db.sqlite')
        conn.row_factory = sqlite3.Row
    

#Close connection
def close():
    if conn:
        conn.close()

#Make rows
def make_tasks(row):
    return Task(row["taskID"], row["description"], row["completed"])


#Get the tasks
def get_tasks(task_id):
    sql = '''SELECT * FROM Task'''
    with closing(conn.cursor()) as c:
        c.execute(sql)
        results = c.fetchall()

        tasks = []
        for row in results:
            movies.append(make_tasks(row))
        return tasks

    

#add task
def add_task(task):
    sql = '''INSERT INTO Task (taskID, description, completed) 
             VALUES (?, ?, ?)'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (task.task.id, task.description, task.completed))

        conn.commit()

#delete a task
def delete_task(task_id):
    sql = '''DELETE FROM Task WHERE movieID = ?'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (task_id,))
        test = conn.commit()
        #print("Test", test)

        conn.commit()

#Update a task
def update_task(task_id):
    sql = '''UPDATE Task set completed = 1 WHERE taskID = ?'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (task_id,))

        conn.commit()
        

