#Name: Eyob Chekle
#Assignment: Chapter 17 Task List Application
#Date: 11/18/22
#Description: Create a program that allows you to manage a task list that’s stored in a database.

#Imports
import ch17_Task_List_Presentation_EFC as presentation
import ch17_Task_List_Database_EFC as database




#display menu
def display_menu():
    print("COMMAND MENU")
    print("view  - View pending tasks")
    print("history - View completed tasks")
    print("add  - Add a task")
    print("complete  - Complete a task")
    print("delete - Delete a task")
    print("exit - Exit program")
    print()

#View pending tasks
def view_tasks(conn):
    try:
        taskID = 1
        database.get_tasks(1)
    except Exception as e:
        print("There was an error in this module")
    

#View completed tasks
def view_completed_tasks():
    pass

#add a task
def add_task():
    try:
        description = input("Description: ")
        completed = 0
        Task(description, completed)
        database.add_task(Task)
    except Exception as e:
        print("There was an error in this module")
        

#complete a task
def complete_task():
    try:
        num = int(input("Task ID: "))
        database.update_task(num)
    except Exception as e:
        print("There was an error in this module")

#delete a task
def delete_task():
    try:
        number = input("Task ID: ")
        database.delete_task(number)
    except Exception as e:
        print("There was an error in this module")


def main():
    database.connect()
    #display_title()
    display_menu()
    conn = database.connect()
    while True:        
        command = input("Command: ")
        if command == "view":
            view_tasks(conn)
        elif command == "history":
            view_completed_tasks()
        elif command == "add":
            add_task()
        elif command == "complete":
            complete_task()
        elif command == "delete":
            delete_task
        elif command == "exit":
            break
        else:
            print("Not a valid command. Please try again.\n")
            display_menu()
    database.close()
    print("Bye!")

if __name__ == "__main__":
    main()
