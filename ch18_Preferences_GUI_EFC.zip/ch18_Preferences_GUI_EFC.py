#Name: Eyob Chekle
#Date: 12/1/2022
#Assignment: Chapter 18 Preferences GUI
#Description: This is the GUI Frame Module for CH18 Preferences assignment

#Imports
import tkinter as tk
from tkinter import ttk
import ch18_Preferences_IO_EFC as GUI

#Main
#Main function
def main():
    GUI.ui()
    




if __name__ == "__main__":
    main()
