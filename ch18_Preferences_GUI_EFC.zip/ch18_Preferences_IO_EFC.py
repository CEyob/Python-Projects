#Name: Eyob Chekle
#Date: 12/1/2022
#Assignment: Chapter 18 Preferences GUI
#Description: This is the GUI Frame Module for CH18 Preferences assignment

#File names
FileIO = "preferences.txt"

#Import statements
import tkinter as tk
from tkinter import ttk

#Function for reading from txt file

def readFromTextFile():
    name = ""
    language = "English"
    auto_save = 5
    
    try:
        with open(FileIO, "r"):
            name = FileIO.readlines().strip()
            language = FileIO.readlines().strip()
            auto_save = int(FileIO.readlines().strip())

            #set the values equal to it
            name.set(name_txt)
            language.set(language)
            auto_save_minutes.set(str(auto_save))
    except Exception as e:
        print("There was an error while reading from the text file.")
        #print(type(e))
        #print(e)

def writeToTextFile():
    name = ""
    language = "English"
    auto_save = 5
    

    errorValue = 0
    if len(name) == 0:
        #name_validation.set("Required")
        errorValue = 1
    elif len(language) == 0:
        #language_validation.set("Required")
        errorValue = 1
    else:
        try:
            with open("preferences.txt", "w", newline = ""):
                write(name.get() + "\n")
                write(language.get() + "\n")
                write(auto_save_minutes.get() + "\n")

        except Exception as e:
            print("There was an error with saving to the text file.")
            print(type(e))
        
    
        


#UI Function
def ui():
    #Create the root object with the TK Constructor method
    root = tk.Tk()

    #Set title
    root.title("Preferences")

    name = tk.StringVar()
    language = tk.StringVar()
    auto_save_minutes = tk.StringVar()

    name_validation = tk.StringVar()
    language_validation = tk.StringVar()
    auto_save_validation = tk.StringVar()
    
    #Name Row for the GUI
    ttk.Label(master = root, text= "Name:").grid(column=0, row=0, sticky=tk.E)
    ttk.Entry(root, textvariable = name).grid(column=1, row=0, columnspan = 1, sticky=tk.E)
    ttk.Label(root, text = " ", textvariable = name_validation).grid(column=3, row=0, sticky=tk.E)

    #Language row for the GUI
    ttk.Label(master = root, text= "Language:").grid(column=0, row=1, sticky=tk.E)
    ttk.Entry(root, textvariable = language).grid(column=1, row=1, columnspan = 1, sticky=tk.E)
    ttk.Label(root, text = " ", textvariable = language_validation).grid(column=3, row=1, sticky=tk.E)

    #Auto Save row for the GUI
    ttk.Label(master = root, text= "Auto Save; Every X Mins:").grid(column=0, row=2, sticky=tk.E)
    ttk.Entry(root, textvariable = auto_save_minutes).grid(column=1, row=2, columnspan = 1, sticky=tk.E)
    ttk.Label(root, text = " ", textvariable = auto_save_validation).grid(column=3, row=2, sticky=tk.E)

    #Save or Cancel buttons
    ttk.Button(text = "Save", command=writeToTextFile()).grid(column=1, row=3, sticky=tk.E)
    ttk.Button(text = "Cancel", command=root.destroy).grid(column=2, row=3, sticky=tk.E)

    readFromTextFile()
    root.mainloop()

    
               


###Main function
##def main():
##    #Create the root object with the TK Constructor method
####    root = tk.Tk()
####
####    #Set title
####    root.title("Preferences")
####
####    name = tk.StringVar()
####    lang = tk.StringVar()
####    auto_save_minutes = tk.StringVar()
####
####    name_validation = tk.StringVar()
####    language_validation = tk.StringVar()
####    auto_save_validation = tk.StringVar()
##
##    ui()













##
##if __name__ == "__main__":
##    main()

    

        
            
    
        

